from django.shortcuts import render
from .models import Post1

# Create your views here.

def index(request):
    posts = Post1.objects.all()
    return render(
        request,
        'blog/index.html',
        {
            'post_list' : posts
        }
     )
    # select * from Post1 order by asc pk

def index_reverse(request):
    posts = Post1.objects.all().order_by('-pk')
    return render(
        request,
        'blog/index.html',
        {
            'post_list' : posts
        }
     )

    # select * from Post1 order by desc pk

def gugudan(request):
    gugudan_list = []
    for dan in range(2,10):
        for i in range(1,10):
            expr = '%d x %d = %d' % (dan, i, dan*i)
            # expr = "2 x 1 = 2"
            gugudan_list.append(expr)

    return render(
        request,
        'gugudan/gugudan.html',
        {
            'gugudan_list' : gugudan_list
        }
    )