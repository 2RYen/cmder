from django.urls import path, include
from . import views

urlpatterns = [
    path('gugudan/', views.gugudan),
    path('gugudan/<int:dan>', views.gugudan_get)
]