from django.contrib import admin
from .models import PostCBV
# Register your models here.

admin.site.register(PostCBV)