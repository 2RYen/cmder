from django.shortcuts import render
from django.views.generic import ListView, DetailView
from .models import PostCBV

# Create your views here.
class PostCBVList(ListView):
    model = PostCBV
    template_name = 'blog_cbv/index.html'
    # context_object_name = 'posts'
    # table_name = 'PostCBV'

class PostCBVDetail(DetailView):
    model = PostCBV
    template_name = "blog_cbv/index2.html"
    context_object_name = "postCBV"