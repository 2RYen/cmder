from django.shortcuts import render
from .models import Post


# Create your views here.
def index(request):
    greeting = 'Hello World !!!!!'
    posts = Post.objects.all()  #select * from Post

    return render(
        request,
        'blog/index.html',
        {
            'greet': greeting,
            'posts': posts
        }
    )


def sing_post_page(request, pri_key):
    post = Post.objects.get(pk=pri_key)
    return render(
        request,
        'blog/single_post_pages.html',
        {
            'post': post
        }
    )



def index2(request):
    greeting = 'Hello World !!!!!'
    posts = Post.objects.all()  #select * from Post

    return render(
        request,
        'blog/index2.html',
        {
            'greet': greeting,
            'posts': posts
        }
    )


def index3(request):
    posts = Post.objects.all()

    return render(
        request,
        'blog/index3.html',
        {
            'posts': posts
        }
    )


def gugudan(request):
    dan = 2
    str_gugu = ""
    for i in range(1,10):
        str_gugu += '%d X %d = %d\n' % (dan, i, dan*i)

    return render(
        request,
        'blog/gugudan.html',
        {
            'gugu_print': str_gugu
        }
    )