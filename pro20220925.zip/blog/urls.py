from django.urls import path, include
from . import views


urlpatterns = [
    path('', views.index),
    path('index2/', views.index2),
    path("index3/", views.index3),
    path("<int:pri_key>/", views.sing_post_page),
    path("gugudan/", views.gugudan)
]