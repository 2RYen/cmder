from django.apps import AppConfig


class MigrationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'migrations'
