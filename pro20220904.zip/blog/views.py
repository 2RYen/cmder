from django.shortcuts import render
from blog.models import Post

# Create your views here.
def index(request):
    postss = Post.objects.all()  #select = from Post
    return render(
        request,
        'blog/hello.html',
        {
            'posts' : postss
        }
    )