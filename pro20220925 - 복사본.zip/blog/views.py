from django.shortcuts import render
from .models import Post


# Create your views here.
def index(request):
    greeting = 'Hello World !!!!!'
    posts = Post.objects.all()  #select * from Post

    return render(
        request,
        'blog/index.html',
        {
            'greet': greeting,
            'posts': posts
        }
    )