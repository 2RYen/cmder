from django.shortcuts import render

# Create your views here.
def index(request):
    greeting = '안녕~'
    return render(
        request,
        'blog/index.html',
        {
            'greeting': greeting,
        }
    )