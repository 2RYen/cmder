from django.shortcuts import render

# Create your views here.
def gugudan_all(request):
    gugudan_list = []
    for dan in range(2,10):
        for i in range(1,10):
            expr = "%d x %d = %d" % (dan, i, dan*i)
            gugudan_list.append(expr)
    return render(
        request,
        'utility/gugudan.html',
        {
            'gugudan_list' : 'gugudan_list'
        }
    )


def gugudan(request, dan):
    gugudan_list = []
    for i in range(1,10):
        expr = "%d x %d = %d" % (dan, i, dan*i)
        gugudan_list.append(expr)
    return render(
        request,
        'utility/gugudan.html',
        {
            'gugudan_list': gugudan_list
        }
    )