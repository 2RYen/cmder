from django.urls import path
from .import views

urlpatterns = [
    path('gugudan/', views.gugudan_all),
    path('gugudan/<int:dan>', views.gugudan)
]