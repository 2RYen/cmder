from django.shortcuts import render
from .forms import GugudanForm


# Create your views here.
def index(request):
    greeting = "홍길순"
    return render(
        request,
        "utility/index.html",
        {
            "greetings": greeting,
        }
    )


def gugudan_all(request):
    gugudan_list = []
    for dan in range(2,10):
        for i in range(1,10):
            expr = "%d x %d = %d" % (dan, i, dan*i)
            gugudan_list.append(expr)
        gugudan_list.append("")
    return render(
        request,
        "utility/gugudan.html",
        {
            "gugudan_list": gugudan_list,
        }
    )


def gugudan(request, dan):
    gugudan_list = []
    for i in range(1,10):
        expr = "%d x %d = %d" % (dan, i, dan*i)
        gugudan_list.append(expr)
    return render(
        request,
        "utility/gugudan.html",
        {
            "gugudan_list": gugudan_list
        }
    )


def gugudan_form1(request):
    return render(
        request,
        "utility/gugudan_form1.html"
    )


def gugudan_form1_proc(request):
    if request.method == 'POST':
        dan = int(request.POST["dan"])
    else:
        pass
    # print("Dan =====> %d" % dan)
    gugudan_list = []
    for i in range(1,10):
        expr = "%d x %d = %d" % (dan, i, dan*i)
        gugudan_list.append(expr)

    return render(
        request,
        "utility/gugudan.html",
    {
        "gugudan_list": gugudan_list,
    }
    )


def gugudan_form2(request):
    if request.method == 'POST':
        form = GugudanForm(request.POST)
    else:
        form = GugudanForm()


    return render(
        request,
        'utility/gugudan_form2.html',
        {
            'form1': form,
        }
    )