from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path("gugudan/",  views.gugudan_all),
    path("gugudan/<int:dan>", views.gugudan),

    path("gugudan/form1", views.gugudan_all),
    path("gugudan/form1/<int:dan>", views.gugudan),
    path("gugudan/form1/gugudan_form1", views.gugudan_form1),
    path("gugudan/form1/gugudan_form1_proc1", views.gugudan_form1_proc, name="gugudan_form1_proc"),

    path("gugudan/form2", views.gugudan_all),
    path("gugudan/form2/<int:dan>", views.gugudan),
    path("gugudan/form2/gugudan_form2", views.gugudan_form2, name='gugudan_form2_proc')
]
