from django.contrib import admin
from .models import Post
from .models import Post2

# Register your models here.
admin.site.register(Post)
admin.site.register(Post2)