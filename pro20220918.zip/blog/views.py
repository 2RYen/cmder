from django.shortcuts import render

# Create your views here.
def hello1(request):
    return render(
        request,
        'blog/hello.html'
    )